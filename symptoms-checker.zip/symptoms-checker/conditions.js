export const lib = [
    {
      likely_condition: "common cold",
        symptoms: ["sore throat", "cough", "runny nose"],
        severity: "mild",
        recommendation: "rest, drink fluids, and take over-the-counter medicine if needed."
      },
    {
      likely_condition: "covid",
        symptoms: ["fever", "headache", "nausea"],
        severity: "moderate",
        recommendation: "rest, drink fluids, and take over-the-counter medicine if needed."
      }, 
    {
      likely_condition: "allergy",
        symptoms: ["sneezing", "itchy eyes", "runny nose"],
        severity: "mild",
        recommendation: "stay away from what is casuing the allergy, take an antihistamine."
      },
    {
      likely_condition: "heart attack",
        symptoms: ["chest pain", "shortness of breath", "numbness", "dizziness"],
        severity: "severe",
        recommendation: "call emergency services immediately.",
     },
    {
      likely_condition: "migraine",
        symptoms: ["headahce", "sensitivity to light", "sensitivity to loud sounds"],
        severity: "mild",
        recommendation: "rest and take prescribed or over-the-counter pain relievers"
      },
    {
      likely_condition: "food poisoning",
        symptoms: ["vomiting", "diarrhea", "stomach cramps", "nausea"],
        severity: "moderate",
        recommendation: "stay hydrated and rest. Seek medical help if symptoms last more than 2 days."
      },
    {
      likely_condition: "flu",
        symptoms: ["fever", "chills", "muscle aches", "fatigue"],
        severity: "moderate",
        recommendation: "rest, drink fluids, and use fever-reducing medication if needed."
      },
]