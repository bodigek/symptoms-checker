this is a simple node.js app that checks a user's symptoms against a local condition list created, or uses chatgpt to give a possible diagnosis recommendation, and severity.

how it works: 
- the code starts by asking the user a question in the terminal and takes in their response.
- for the symptom it checks a local list of conditions in conditions.js that i created.
- each condition has a list of symptoms like "cough", "sore throat".
- if at least some of the symptoms in a condition are found in the sentence then that condition is returned with a recommendation and severity and the result is printed to the console and there is no need to ask chatgpt.
- if no condition matches meaning none of what was inputted matched any symptoms in conditions.js then the symptom is sent to chatgpt with a request to respond in JSON format. chatgpt replies with a condition, recommendation, and severity.
- you see the result in your terminal for each symptom either from your own list or from chatgpt.

files used:
index.js - main file
conditions.js - custom symptom library
.env - stores my OpenAI API key
package.json - project config with dependencies

how to run it:
1. make sure Node.js is installed
2. install dependecies using 'npm install'
3. create a .env file with your OpenAI key
4. run the bot with 'node index.js'
5. enter you symptoms when prompted
6. wait for result