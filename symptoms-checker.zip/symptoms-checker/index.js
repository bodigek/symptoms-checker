import * as dotenv from "dotenv";
dotenv.config();
import OpenAI from "openai";
import express from "express";
import cors from "cors";
import { lib } from "./conditions.js"; // expected shape: [{ condition or likely_condition, symptoms:[], recommendation, severity }]

const ai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const app = express();
app.use(cors());
app.use(express.json());

function checkLocal(input) {
  const text = String(input).toLowerCase();

  for (const item of lib) {
    const symptoms = (item.symptoms || []).map(s => String(s).toLowerCase());
    const someMatch = symptoms.some(sym => text.includes(sym));
    if (someMatch) {
      const name = item.likely_condition || item.condition || "unknown";
      return {
        likely_condition: name,
        recommendation: item.recommendation || "",
        severity: item.severity || "unknown",
        source: "local",
      };
    }
  }
  return null;
}

app.post("/check", async (req, res) => {
  try {
    const symptom = (req.body?.symptom || "").trim();
    if (!symptom) return res.status(400).json({ error: "symptom is required" });

    // 1) local first
    const local = checkLocal(symptom);
    if (local) return res.json(local);

    // 2) fall back to OpenAI
    const prompt =
      `${symptom}\n` +
      `If you do not recognize a related condition, return "unknown" as the likely_condition.\n` +
      `Always respond ONLY in strict JSON with keys: likely_condition, recommendation, severity.`;

    const completion = await ai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a medical assistant. Reply ONLY with valid JSON." },
        { role: "user", content: prompt },
      ],
      temperature: 0,
    });

    const raw = completion.choices?.[0]?.message?.content ?? "{}";

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch {
      // super-safe fallback
      parsed = {
        likely_condition: "unknown",
        recommendation: "Unable to determine. Consider basic self-care and seek medical advice if symptoms worsen.",
        severity: "unknown",
      };
    }

    return res.json({
      likely_condition: parsed.likely_condition ?? "unknown",
      recommendation: parsed.recommendation ?? "",
      severity: parsed.severity ?? "unknown",
      source: "ai",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "server error" });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
});
